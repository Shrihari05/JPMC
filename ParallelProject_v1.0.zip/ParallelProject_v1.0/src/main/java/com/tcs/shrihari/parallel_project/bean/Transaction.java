package com.tcs.shrihari.parallel_project.bean;
import java.sql.Timestamp;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Transaction {
	long refNumber;
	Timestamp dateTime;
	long senderAccNumber;
	String senderName;
	long receiverAccNumber;
	String receiverName;
	double amount;
	String type;
	
}


