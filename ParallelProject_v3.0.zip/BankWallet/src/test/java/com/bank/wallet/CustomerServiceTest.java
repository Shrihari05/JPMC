package com.bank.wallet;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import com.bank.wallet.beans.Customer;
import com.bank.wallet.exceptions.FundTransferLimitError;
import com.bank.wallet.exceptions.LoginError;
import com.bank.wallet.exceptions.SignUpError;
import com.bank.wallet.exceptions.WalletExceptions;
import com.bank.wallet.repositories.CustomerRepository;
import com.bank.wallet.services.CustomerService;

@ExtendWith(MockitoExtension.class)
public class CustomerServiceTest {
	@Mock
	private CustomerRepository repo;

	@InjectMocks
	private CustomerService customerService;

	@Test
	void testSignUp_Valid() {
		Customer mockCustomer = new Customer("Shri@2000", "Paltan@2025");
		when(repo.save(mockCustomer)).thenReturn(mockCustomer);
		Customer serviceCustomer = customerService.signUp(mockCustomer);
		assertEquals(mockCustomer, serviceCustomer);
		verify(repo).save(mockCustomer);
	}

	@Test
	void testSignUp_InValid() {
		Customer mockCustomer = new Customer("Shri@2000", "Paltan@2025");
		when(repo.save(mockCustomer)).thenThrow(new SignUpError());

		SignUpError thrown = assertThrows(SignUpError.class, () -> {
			customerService.signUp(mockCustomer);
		});

		ResponseEntity<Object> response = new WalletExceptions().SignUpError(thrown);
		assertEquals("Signup failed! Please try again!", String.valueOf(response.getBody()));
		verify(repo).save(mockCustomer);
	}

	@Test
	void testLogin_Valid() {
		Customer mockCustomer = new Customer("Shri@2000", "Paltan@2025");

		when(repo.findByUserIdAndPassword(mockCustomer.getUserId(), mockCustomer.getPassword()))
				.thenReturn(Optional.of(mockCustomer));

		boolean loginResult = customerService.login(mockCustomer);

		assertTrue(loginResult);
		verify(repo).findByUserIdAndPassword(mockCustomer.getUserId(), mockCustomer.getPassword());

	}

	@Test
	void testLogin_Error() {
		Customer mockCustomer = new Customer("Shri@2000", "Paltan@2025");

		when(repo.findByUserIdAndPassword(mockCustomer.getUserId(), mockCustomer.getPassword()))
				.thenThrow(new LoginError());

		LoginError thrown = assertThrows(LoginError.class, () -> {
			customerService.login(mockCustomer);
		});

		ResponseEntity<Object> response = new WalletExceptions().LoginError(thrown);
		assertEquals("Login failed! Please try again!", String.valueOf(response.getBody()));

		verify(repo).findByUserIdAndPassword(mockCustomer.getUserId(), mockCustomer.getPassword());

	}

	@Test
	void testLogin_InValid() {
		Customer mockCustomer = new Customer("Shri@2000", "Paltan@2025");

		when(repo.findByUserIdAndPassword(mockCustomer.getUserId(), mockCustomer.getPassword()))
				.thenReturn(Optional.empty());

		boolean loginResult = customerService.login(mockCustomer);

		assertFalse(loginResult);
		verify(repo).findByUserIdAndPassword(mockCustomer.getUserId(), mockCustomer.getPassword());

	}

	@Test
	void testFindById_Exists() {
		Customer mockCustomer = new Customer("Shri@2000", "Paltan@2025");

		when(repo.findById(mockCustomer.getUserId())).thenReturn(Optional.of(mockCustomer));

		Optional<Customer> serviceCustomer = customerService.findById(mockCustomer.getUserId());

		assertTrue(serviceCustomer.isPresent());
		assertEquals("Shri@2000", serviceCustomer.get().getUserId());
		verify(repo).findById(mockCustomer.getUserId());
	}

	@Test
	void testFindById_NotExists() {
		when(repo.findById("Shri@20")).thenReturn(Optional.empty());
		Optional<Customer> serviceCustomer = customerService.findById("Shri@20");

		assertFalse(serviceCustomer.isPresent());
		verify(repo).findById("Shri@20");
	}

}
