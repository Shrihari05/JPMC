package com.tcs.shrihari.parallel_project;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.tcs.shrihari.parallel_project.ui.App;

class Main{
public static void main(String[] args) {
	ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("context.xml");
	App a= context.getBean("app",App.class);
	a.start();
}
}