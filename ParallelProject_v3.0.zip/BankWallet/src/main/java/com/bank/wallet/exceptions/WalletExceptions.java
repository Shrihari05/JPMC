package com.bank.wallet.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class WalletExceptions {

	@ExceptionHandler(value = NoAccountError.class)
	public ResponseEntity<Object> NoAccountError(NoAccountError exception){
		
		return new ResponseEntity<>("User does not have an account.", HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(value = FundTransferLimitError.class)
	public ResponseEntity<Object> FundTransferLimitError(FundTransferLimitError exception){
		
		return new ResponseEntity<>("Amount is not within Fund transfer limit.", HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(value = AccountCreationError.class)
	public ResponseEntity<Object> AccountCreationError(AccountCreationError exception){
		
		return new ResponseEntity<>("Account creation failed! Please Try again!", HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(value = NoTransactionException.class)
	public ResponseEntity<Object> NoTransactionException(NoTransactionException exception){
		
		return new ResponseEntity<>("No transactions are made", HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(value = FundTransferError.class)
	public ResponseEntity<Object> FundTransferError(FundTransferError exception){
		
		return new ResponseEntity<>("Error in Fund Transfer!Please try again!", HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(value = SignUpError.class)
	public ResponseEntity<Object> SignUpError(SignUpError exception){
		
		return new ResponseEntity<>("Signup failed! Please try again!", HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(value = LoginError.class)
	public ResponseEntity<Object> LoginError(LoginError exception){
		
		return new ResponseEntity<>("Login failed! Please try again!", HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(value = NoUserError.class)
	public ResponseEntity<Object> NoUserError(NoUserError exception){
		
		return new ResponseEntity<>("User doesn't exists.", HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(value = WithdrawLimitError.class)
	public ResponseEntity<Object> WithdrawLimitError(WithdrawLimitError exception){
		
		return new ResponseEntity<>("Amount not within the withdraw limit (Min100 Max5000)", HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(value = WithdrawError.class)
	public ResponseEntity<Object> WithdrawError(WithdrawError exception){
		
		return new ResponseEntity<>("Error in withdrawing amount!Please try again!", HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(value = DepositError.class)
	public ResponseEntity<Object> DepositError(DepositError exception){
		
		return new ResponseEntity<>("Error in depositing amount!Please try again!", HttpStatus.NOT_FOUND);
	}
	
	
}
