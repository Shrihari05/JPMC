package com.bank.wallet.exceptions;

public class NoUserError extends RuntimeException {
	
}
