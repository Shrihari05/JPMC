package com.tcs.shrihari.parallel_project.exceptions;

public class WithDrawError extends Exception {
public WithDrawError(String message) {
	super(message);
}
}
