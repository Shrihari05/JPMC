package com.tcs.shrihari.parallel_project.exceptions;

public class ReceipientNotPresentError extends Exception {
	public ReceipientNotPresentError(String message) {
		super(message);
	}
}
