package com.bank.wallet.exceptions;

public class SignUpError extends RuntimeException {
	
}
