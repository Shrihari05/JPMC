package com.tcs.shrihari.parallel_project.exceptions;

public class NoTransactionException extends Exception {
	public NoTransactionException(String message) {
		super(message);
	}
}
