package com.bank.wallet;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.aspectj.lang.annotation.Before;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import static org.mockito.Mockito.any;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;

import com.bank.wallet.beans.Account;
import com.bank.wallet.beans.Customer;
import com.bank.wallet.beans.Transactions;
import com.bank.wallet.exceptions.DepositError;
import com.bank.wallet.exceptions.FundTransferError;
import com.bank.wallet.exceptions.FundTransferLimitError;
import com.bank.wallet.exceptions.NoAccountError;
import com.bank.wallet.exceptions.NoTransactionException;
import com.bank.wallet.exceptions.WalletExceptions;
import com.bank.wallet.exceptions.WithdrawError;
import com.bank.wallet.exceptions.WithdrawLimitError;
import com.bank.wallet.repositories.TransactionRepository;
import com.bank.wallet.services.AccountService;
import com.bank.wallet.services.CustomerService;
import com.bank.wallet.services.TransactionService;

@ExtendWith(MockitoExtension.class)
@SpringBootTest
public class TransactionServiceTest {
	@Mock
	TransactionRepository repo;
	@Mock
	AccountService accountService;
	@Mock
	CustomerService customerService;
	@InjectMocks
	TransactionService transactionService;

	Customer mockCustomer, mockReceiver;
	Account mockAccount, mockReceiverAccount;
	Transactions mockTransaction;

	@BeforeEach
	void setUp() throws ParseException {
		SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
		mockCustomer = new Customer("Shri@2000", "Paltan@2025");
		mockAccount = new Account(27890190, mockCustomer, "Shrihari",
				new java.sql.Date(df.parse("2000-09-09").getTime()), 9090989890l, "Whitefield,Bangalore", "Savings",
				5000.0);
		mockReceiver = new Customer("Hari@2000", "Mumbai@2025");
		mockReceiverAccount = new Account(27890189, mockReceiver, "Hari S",
				new java.sql.Date(df.parse("2000-09-09").getTime()), 9090989890l, "Whitefield,Bangalore", "Savings",
				5000.0);
		mockTransaction = new Transactions(49002904903l, new java.sql.Timestamp(System.currentTimeMillis()),
				mockAccount.getAccountNumber(), mockAccount.getCustomer(), 0l, null, 0, "");

	}

	@Test
	void testDeposit_Success() {
		double creditAmount = 1500.0;
		mockTransaction.setAmount(creditAmount);
		mockTransaction.setType("Credit");
		when(accountService.getAccountByUserId(mockCustomer.getUserId())).thenReturn(Optional.of(mockAccount));
		when(accountService.updateAccount(mockAccount)).thenReturn(mockAccount);
		when(repo.save(any(Transactions.class))).thenReturn(mockTransaction);

		Transactions depositTransaction = transactionService.deposit(mockCustomer.getUserId(), creditAmount);

		assertNotNull(depositTransaction);
		assertEquals(creditAmount, depositTransaction.getAmount());
		verify(accountService).getAccountByUserId(mockCustomer.getUserId());
		verify(accountService).updateAccount(mockAccount);
		verify(repo).save(any(Transactions.class));

	}

	@Test
	void testDeposit_NoAccountError() {
		when(accountService.getAccountByUserId(mockCustomer.getUserId())).thenReturn(Optional.empty());
//	        when(accountService.updateAccount(mockAccount)).thenThrow(new Error());
		NoAccountError thrown = assertThrows(NoAccountError.class, () -> {
			transactionService.deposit(mockCustomer.getUserId(), 5000.0);
		});

		ResponseEntity<Object> response = new WalletExceptions().NoAccountError(thrown);
		assertEquals("User does not have an account.", String.valueOf(response.getBody()));
		verify(accountService).getAccountByUserId(mockCustomer.getUserId());
	}

	@Test
	void testDeposit_Error() {
		when(accountService.getAccountByUserId(mockCustomer.getUserId())).thenReturn(Optional.of(mockAccount));
		when(accountService.updateAccount(mockAccount)).thenThrow(new DepositError());
		DepositError thrown = assertThrows(DepositError.class, () -> {
			transactionService.deposit(mockCustomer.getUserId(), 5000.0);
		});

		ResponseEntity<Object> response = new WalletExceptions().DepositError(thrown);
		assertEquals("Error in depositing amount!Please try again!", String.valueOf(response.getBody()));
		verify(accountService).updateAccount(mockAccount);
	}

	@Test
	void testWithdraw() {
		double debitAmount = 1500.0;
		mockTransaction.setAmount(debitAmount);
		mockTransaction.setType("Debit");
		when(accountService.getAccountByUserId(mockCustomer.getUserId())).thenReturn(Optional.of(mockAccount));
		when(accountService.updateAccount(mockAccount)).thenReturn(mockAccount);
		when(repo.save(any(Transactions.class))).thenReturn(mockTransaction);

		Transactions withdrawTransaction = transactionService.withdraw(mockCustomer.getUserId(), debitAmount);

		assertNotNull(withdrawTransaction);
		assertEquals(debitAmount, withdrawTransaction.getAmount());
		verify(accountService).getAccountByUserId(mockCustomer.getUserId());
		verify(accountService).updateAccount(mockAccount);
		verify(repo).save(any(Transactions.class));
	}

	@Test
	void testWithdraw_NoAccountError() {
		when(accountService.getAccountByUserId(mockCustomer.getUserId())).thenReturn(Optional.empty());
		NoAccountError thrown = assertThrows(NoAccountError.class, () -> {
			transactionService.withdraw(mockCustomer.getUserId(), 5000.0);
		});

		ResponseEntity<Object> response = new WalletExceptions().NoAccountError(thrown);
		assertEquals("User does not have an account.", String.valueOf(response.getBody()));
		verify(accountService).getAccountByUserId(mockCustomer.getUserId());
	}

	@Test
	void testWithdraw_Error() {
		when(accountService.getAccountByUserId(mockCustomer.getUserId())).thenReturn(Optional.of(mockAccount));
		when(accountService.updateAccount(mockAccount)).thenThrow(new WithdrawError());
		WithdrawError thrown = assertThrows(WithdrawError.class, () -> {
			transactionService.deposit(mockCustomer.getUserId(), 5000.0);
		});

		ResponseEntity<Object> response = new WalletExceptions().WithdrawError(thrown);
		assertEquals("Error in withdrawing amount!Please try again!", String.valueOf(response.getBody()));
		verify(accountService).updateAccount(mockAccount);
	}

	@Test
	void testWithdraw_LimitError() {
		when(accountService.getAccountByUserId(mockCustomer.getUserId())).thenReturn(Optional.of(mockAccount));

		WithdrawLimitError thrown = assertThrows(WithdrawLimitError.class, () -> {
			transactionService.withdraw(mockCustomer.getUserId(), 100000.0);
		});

		ResponseEntity<Object> response = new WalletExceptions().WithdrawLimitError(thrown);
		assertEquals("Amount not within the withdraw limit (Min100 Max5000)", String.valueOf(response.getBody()));
		verify(accountService).getAccountByUserId(mockCustomer.getUserId());
	}

	@Test
	void testFundTransfer_Success() {
		double fundAmount = 1500.0;
		mockTransaction.setAmount(fundAmount);
		mockTransaction.setReceiver(mockReceiver);
		mockTransaction.setReceiverAccNumber(mockReceiverAccount.getAccountNumber());
		mockTransaction.setType("FundTransfer");
		when(customerService.findById(mockReceiver.getUserId())).thenReturn(Optional.of(mockReceiver));
		when(accountService.getAccountByUserId(mockCustomer.getUserId())).thenReturn(Optional.of(mockAccount));
		when(accountService.getAccountByUserId(mockReceiver.getUserId())).thenReturn(Optional.of(mockReceiverAccount));
		when(accountService.updateAccount(mockAccount)).thenReturn(mockAccount);
		when(accountService.updateAccount(mockReceiverAccount)).thenReturn(mockReceiverAccount);
		when(repo.save(any(Transactions.class))).thenReturn(mockTransaction);

		Transactions fundTransaction = transactionService.fundTransfer(mockCustomer.getUserId(),
				mockReceiver.getUserId(), fundAmount);

		assertNotNull(fundTransaction);
		assertEquals(fundAmount, fundTransaction.getAmount());
		verify(accountService).getAccountByUserId(mockCustomer.getUserId());
		verify(accountService).updateAccount(mockAccount);
		verify(repo).save(any(Transactions.class));
	}

	@Test
	void testFundTransfer_LimitError() {
		when(customerService.findById(mockReceiver.getUserId())).thenReturn(Optional.of(mockReceiver));

		FundTransferLimitError thrown = assertThrows(FundTransferLimitError.class, () -> {
			transactionService.fundTransfer(mockCustomer.getUserId(), mockReceiver.getUserId(), 100000.0);
		});

		ResponseEntity<Object> response = new WalletExceptions().FundTransferLimitError(thrown);
		assertEquals("Amount is not within Fund transfer limit.", String.valueOf(response.getBody()));
		verify(customerService).findById(mockReceiver.getUserId());
	}

	@Test
	void testFundTransfer_Error() {
		when(customerService.findById(mockReceiver.getUserId())).thenReturn(Optional.of(mockReceiver));
		when(accountService.getAccountByUserId(mockCustomer.getUserId())).thenReturn(Optional.of(mockAccount));
		when(accountService.getAccountByUserId(mockReceiver.getUserId())).thenReturn(Optional.of(mockReceiverAccount));
		when(transactionService.debitAmount(mockCustomer.getUserId(), 1000.0)).thenReturn(mockAccount);
		when(transactionService.creditAmount(mockReceiver.getUserId(), 1000.0)).thenReturn(mockReceiverAccount);

		mockTransaction.setSender(mockCustomer);
		mockTransaction.setReceiver(mockReceiver);
		mockTransaction.setAmount(1000.0);
		when(repo.save(any(Transactions.class))).thenThrow(new FundTransferError());
		FundTransferError thrown = assertThrows(FundTransferError.class, () -> {
			transactionService.fundTransfer(mockCustomer.getUserId(), mockReceiver.getUserId(), 1000.0);
		});

		ResponseEntity<Object> response = new WalletExceptions().FundTransferError(thrown);
		assertEquals("Error in Fund Transfer!Please try again!", String.valueOf(response.getBody()));
		verify(repo).save(any(Transactions.class));
	}

	@Test
	void testPrintTransactions() {
		List<Transactions> mockTransactions = new ArrayList<>();

		when(repo.findBySenderUserId(mockCustomer.getUserId())).thenReturn(mockTransactions);
		List<Transactions> serviceTransactions = (List<Transactions>) (transactionService
				.printTransactions(mockCustomer.getUserId()));
		assertEquals(mockTransactions, serviceTransactions);

		verify(repo).findBySenderUserId(mockCustomer.getUserId());
	}

	@Test
	void testPrintTransactions_NoUserError() {

		when(repo.findBySenderUserId(mockCustomer.getUserId())).thenReturn(null);
		NoTransactionException thrown = assertThrows(NoTransactionException.class, () -> {
			transactionService.printTransactions(mockCustomer.getUserId());

		});

		ResponseEntity<Object> response = new WalletExceptions().NoTransactionException(thrown);

		assertEquals("No transactions are made", String.valueOf(response.getBody()));

		verify(repo).findBySenderUserId(mockCustomer.getUserId());
	}

}
