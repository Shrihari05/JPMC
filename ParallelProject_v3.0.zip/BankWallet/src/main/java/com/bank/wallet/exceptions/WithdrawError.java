package com.bank.wallet.exceptions;

public class WithdrawError extends RuntimeException {
	
}
