package com.bank.wallet.exceptions;

public class FundTransferLimitError extends RuntimeException {

}
