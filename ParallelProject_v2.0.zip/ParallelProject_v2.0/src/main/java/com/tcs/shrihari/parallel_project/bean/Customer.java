package com.tcs.shrihari.parallel_project.bean;

public class Customer{
	String username;
	String password;
	Account account;
	public Customer(String username,String password) {
		this.username=username;
		this.password=password;
	}
	public Customer(String username, String password, Account account) {
		super();
		this.username = username;
		this.password = password;
		this.account = account;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	
}

