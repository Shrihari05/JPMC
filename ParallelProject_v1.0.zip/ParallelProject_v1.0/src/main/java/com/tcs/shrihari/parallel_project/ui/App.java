package com.tcs.shrihari.parallel_project.ui;

import java.sql.Date;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.tcs.shrihari.parallel_project.bean.Account;
import com.tcs.shrihari.parallel_project.bean.Customer;
import com.tcs.shrihari.parallel_project.bean.Transaction;
import com.tcs.shrihari.parallel_project.exceptions.FundTransferLimitError;
import com.tcs.shrihari.parallel_project.exceptions.MobileNumberError;
import com.tcs.shrihari.parallel_project.exceptions.NoTransactionException;
import com.tcs.shrihari.parallel_project.exceptions.ReceipientNotPresentError;
import com.tcs.shrihari.parallel_project.exceptions.WithDrawError;
import com.tcs.shrihari.parallel_project.exceptions.WithdrawLimitError;
import com.tcs.shrihari.parallel_project.service.*;

public class App {
	public final static Scanner sc = new Scanner(System.in);
	public final static ServiceInterface service = new ServiceClass();
	// public static Account account = null;

	public void enterApplication(Customer c) throws WithdrawLimitError, FundTransferLimitError {
		System.out.println("Welcome to the Wallet");
		b: while (true) {
			System.out.println("Menu\n1. Create Account\n2. Check Balance\n"
					+ "3. Deposit\n4. Withdraw\n5. Fund Transfer\n6. Print Transaction\n7. Exit");

			System.out.println("Enter choice");
			int choice = sc.nextInt();
			sc.nextLine();
			switch (choice) {
			case 1:

				System.out.println("Account Creation");
				boolean valid = false;
				System.out.println("User ID : " + c.getUsername());

				String name = "";
				do {
					try {
						System.out.println("Enter Name");
						name = sc.nextLine();
						for (char ch : name.toCharArray()) {
							if (Character.isDigit(ch)) {
								throw new InputMismatchException("Invalid Input. Name should not contain numbers.");
							}
						}
						valid = true;
					} catch (InputMismatchException e) {
						System.out.println(e.getMessage());
					}

				} while (!valid);

				SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
				Date dob = null;
				do {
					try {
						System.out.println("Enter Date of Birth (dd-mm-yyyy)");
						dob = new java.sql.Date(df.parse(sc.nextLine()).getTime());
						valid = true;
					} catch (ParseException e) {

						System.out.println("Date Error");

					}
				} while (!valid);
				long phone = 0l;
				valid = false;
				do {
					try {
						System.out.println("Enter Phone Number");
						phone = sc.nextLong();
						if (String.valueOf(phone).length() != 10) {
							throw new MobileNumberError("Mobile number must have 10 digits");
						} else {
							valid = true;

						}
					} catch (InputMismatchException e) {
						System.out.println("Invalid input. Please enter the number.");
						sc.next();
					} catch (MobileNumberError e) {
						System.out.println(e.getMessage());
						sc.next();
					}

				} while (!valid);
				sc.nextLine();
				System.out.println("Enter Address");
				String address = sc.nextLine();

				String accountType = "";
				valid = false;
				do {

					System.out.println("Enter Account Type (Savings/Salary)");
					System.out.println("You have to deposit Rs.5000 for opening a savings account");
					try {
						accountType = sc.nextLine();
						valid = true;
					} catch (InputMismatchException e) {
						System.out.println("Invalid Input");
					}
				} while (!valid);
				Account a = null;
				if (accountType.equalsIgnoreCase("Savings")) {
					a = new Account(0l, c.getUsername(), name, dob, phone, address, accountType, 5000.0);
				} else {
					a = new Account(0l, c.getUsername(), name, dob, phone, address, accountType, 0.0);
				}
				boolean result1 = false;
				try {
					result1 = service.createAccount(a);
				} catch (SQLException e) {
					System.out.println("Account Creation Error");
				}
				if (result1) {
					System.out.println("Account created successfully");
					c.setAccount(a);
					// account = a;
					System.out.println("Your account number is " + a.getAccountNumber());
				}

				break;
			case 2:
				System.out.println("Check balance");
				System.out.println("Balance = " + service.checkBalance(c.getAccount()));
				break;

			case 3:
				System.out.println("Deposit to Wallet");
				
				double amt=0.0;
				valid = false;
				do {
					System.out.println("Enter amount to be deposited");
					try {
						amt = sc.nextDouble();
						valid = true;
					} catch (InputMismatchException e) {
						System.out.println("Invalid Input");
						sc.next();
					}
				} while (!valid);
				
				
				if (service.deposit(amt, c.getAccount(),"Deposit")) {
					System.out.println("Deposited successfully");
					System.out.println("Current Balance = " + service.checkBalance(c.getAccount()));
				} else {
					System.out.println("Deposit unsuccessfull");
				}
				break;
			case 4:
				System.out.println("Withdraw from Wallet");
				valid = false;
				do {
					boolean condition = false;
					double amount=0.0;
					do {
						System.out.println("Enter amount to be withdrawn (Min100. Max. 5000)");

						try {
							amount = sc.nextDouble();
							condition= true;
						} catch (InputMismatchException e) {
							System.out.println("Invalid Input");
							sc.next();
						}
					} while (!condition);
										
					if (amount > 5000 || amount < 100) {
						try {
							throw new WithdrawLimitError("Amount is not within the limit");
						} catch (WithdrawLimitError e) {
							System.out.println(e.getMessage());

						}
					} else {
						try {
							if (service.withdraw(amount, c.getAccount(),"Withdraw")) {
								System.out.println("Withdrawn successfully");
								valid = true;
								System.out.println("Current Balance = " + service.checkBalance(c.getAccount()));
							} else {
								System.out.println("Withdrawn unsuccessfull");
							}
						} catch (WithDrawError e) {
							System.out.println(e.getMessage());
						}
					}
				} while (!valid);

				break;
			case 5:
				System.out.println("Fund Transfer");
				valid = false;
				do {
					System.out.println("Recipient Details:");

					System.out.println("Enter Receiver UserID");
					String userid = sc.nextLine();
					System.out.println("Enter Amount to be transferred (Min.50 Max. 10000)");
					double at = sc.nextDouble();
					sc.nextLine();
					if (at < 50 || at > 10000) {
						try {
							throw new FundTransferLimitError("Amount is not within Fund transfer limit");
						} catch (FundTransferLimitError e) {
							System.out.println(e.getMessage());
						}
					} else {
						try {
							if (service.fundTransfer(userid, at, c, c.getAccount())) {
								valid = true;
								System.out.println("Fund has been transferred successfully");
							} else {
								System.out.println("Fund has not been transferred ! Try again!!");
							}
						} catch (ReceipientNotPresentError e) {
							System.out.println(e.getMessage());
						} catch (WithDrawError e) {
							System.out.println(e.getMessage());
						}
					}
				} while (!valid);
				break;

			case 6:
				System.out.println("Transactions:");
				ArrayList<Transaction> transactions;
				try {
					transactions = service.printTransactions(c.getUsername());
					if (transactions == null) {
						System.out.println("No transactions exist");
					} else {
						for (Transaction t : transactions) {
							System.out.println(t);
						}
					}
				} catch (NoTransactionException e) {
					System.out.println(e.getMessage());
				}
				
				break;
			case 7:
				break b;
			}
		}
	}

	public void start() {

		

		system: while (true) {
			System.out.println("\nMenu\n1. Login\n2. SignUp\n3. Logout");
			System.out.println("Enter choice");
			int ch = sc.nextInt();
			sc.nextLine();
			boolean user = false;
			switch (ch) {
			case 1:
				System.out.println("Enter Login Credentials");
				System.out.println("Enter username");
				String username = sc.nextLine();
				System.out.println("Enter Password");
				String password = sc.nextLine();
				Customer c1 = new Customer(username, password, null);
				Customer res = null;

				try {
					res = service.login(c1);
				} catch (SQLException e) {
					System.out.println("Login Error");

				}

				if (res!=null) {
					System.out.println("Logged In successfully");
				
					try {
						new App().enterApplication(res);
					} catch (WithdrawLimitError e) {
						System.out.println(e.getMessage());
					} catch (FundTransferLimitError e) {
						System.out.println(e.getMessage());
					}
				} else {
					System.out.println("Try Again!");
				}
				break;
			case 2:
				System.out.println("User Registeration");
				System.out.println("Enter username");
				String username1 = sc.nextLine();
				System.out.println("Enter Password");
				String password1 = sc.nextLine();
				Customer c2 = new Customer(username1, password1, null);
				try {
					user = service.signUp(c2);
				} catch (SQLException e) {
					System.out.println("Sign Up Error");
				}
				if (user) {
					System.out.println("Signed up successfully");
					try {
						new App().enterApplication(c2);
					} catch (WithdrawLimitError e) {
						System.out.println(e.getMessage());
					} catch (FundTransferLimitError e) {
						System.out.println(e.getMessage());
					}
				} else {
					System.out.println("Try Again!");
				}
				break;
			case 3:
				service.closeConnection();
				System.out.println("System exited");
				break system;
			}

		}
		sc.close();
	}

}
