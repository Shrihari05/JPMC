package com.tcs.shrihari.parallel_project.exceptions;

public class WithdrawLimitError extends Exception {
public WithdrawLimitError(String message) {
	super(message);
}
}
