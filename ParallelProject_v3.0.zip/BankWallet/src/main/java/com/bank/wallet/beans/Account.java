package com.bank.wallet.beans;

import java.sql.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne; 
import jakarta.persistence.JoinColumn; 

@Entity
public class Account {
    @Id
    private long accountNumber;

    @OneToOne 
    @JoinColumn(name = "customer_user_id", referencedColumnName = "userId") 
    private Customer customer;

    private String name;
    private Date dob;
    private long phone;
    private String address;
    private String accountType;
    private double balance;

    public Account() {}

        public Account(long accountNumber, Customer customer, String name, Date dob, long phone, String address,
                   String accountType, double balance) {
        this.accountNumber = accountNumber;
        this.customer = customer; 
        this.name = name;
        this.dob = dob;
        this.phone = phone;
        this.address = address;
        this.accountType = accountType;
        this.balance = balance;
    }



    public long getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(long accountNumber) {
        this.accountNumber = accountNumber;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public long getPhone() {
        return phone;
    }

    public void setPhone(long phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }
}