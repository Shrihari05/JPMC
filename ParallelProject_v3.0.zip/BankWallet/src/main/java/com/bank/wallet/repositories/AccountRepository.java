package com.bank.wallet.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bank.wallet.beans.Account;



@Repository
public interface AccountRepository extends CrudRepository<Account, Long> {
//	//checkBalance
	@Query(value="select balance from account where customer_user_id=:userId",nativeQuery=true)
	Double findBalanceByUserId(@Param("userId")String userId);

	
	//AccountByUserId
	Optional<Account> findByCustomerUserId(String userId);
	
}
