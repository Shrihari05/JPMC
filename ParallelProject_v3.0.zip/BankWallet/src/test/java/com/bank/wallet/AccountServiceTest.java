package com.bank.wallet;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Optional;

import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import com.bank.wallet.beans.Account;
import com.bank.wallet.beans.Customer;
import com.bank.wallet.exceptions.AccountCreationError;
import com.bank.wallet.exceptions.LoginError;
import com.bank.wallet.exceptions.NoAccountError;
import com.bank.wallet.exceptions.WalletExceptions;
import com.bank.wallet.repositories.AccountRepository;
import com.bank.wallet.services.AccountService;
import com.bank.wallet.services.CustomerService;

@ExtendWith(MockitoExtension.class)
@SpringBootTest
public class AccountServiceTest {
	@Mock
	private AccountRepository repo;
	@InjectMocks
	private AccountService accountService;
	@Mock
	private CustomerService customerService;
	Customer mockCustomer;
	Account mockAccount;

	@BeforeEach
	void setUp() throws ParseException {
		SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
		mockCustomer = new Customer("Shri@2000", "Paltan@2025");
		mockAccount = new Account(27890190, mockCustomer, "Shrihari",
				new java.sql.Date(df.parse("2000-09-09").getTime()), 9090989890l, "Whitefield,Bangalore", "Savings",
				5000.0);
	}

	@Test
	void testAccountByUserId_Exists() throws ParseException {

		when(repo.findByCustomerUserId("Shri@2000")).thenReturn(Optional.of(mockAccount));

		Optional<Account> account = accountService.getAccountByUserId("Shri@2000");

		assertTrue(account.isPresent());
		assertEquals("Shri@2000", account.get().getCustomer().getUserId());
		verify(repo).findByCustomerUserId("Shri@2000");
	}

	@Test
	void testAccountByUserId_NotExists() {
		when(repo.findByCustomerUserId("Shri@2000")).thenReturn(Optional.empty());
		Optional<Account> account = accountService.getAccountByUserId("Shri@2000");

		assertFalse(account.isPresent());
		verify(repo).findByCustomerUserId("Shri@2000");
	}

	@Test
	void testCreateAccount_Success() throws ParseException {
		when(customerService.findById(mockCustomer.getUserId())).thenReturn(Optional.of(mockCustomer));

		when(repo.save(mockAccount)).thenReturn(mockAccount);
		Account serviceAccount = accountService.createAccount(mockCustomer.getUserId(), mockAccount);
		assertNotNull(serviceAccount);
		assertEquals(mockCustomer, mockAccount.getCustomer());
		assertEquals(mockAccount, serviceAccount);
		verify(customerService).findById(mockCustomer.getUserId());
		verify(repo).save(mockAccount);
	}

	@Test
	void testCreateAccount_Failure() {
		when(customerService.findById(mockCustomer.getUserId())).thenReturn(Optional.of(mockCustomer));

		when(repo.save(mockAccount)).thenThrow(new AccountCreationError());

		AccountCreationError thrown = assertThrows(AccountCreationError.class, () -> {
			accountService.createAccount(mockCustomer.getUserId(), mockAccount);
		});
		ResponseEntity<Object> response = new WalletExceptions().AccountCreationError(thrown);
		assertEquals("Account creation failed! Please Try again!", String.valueOf(response.getBody()));
		verify(repo).save(mockAccount);
	}

	@Test
	void testUpdateAccount() throws ParseException {
		mockAccount.setBalance(7000.0);
		when(customerService.findById(mockCustomer.getUserId())).thenReturn(Optional.of(mockCustomer));

		when(repo.save(mockAccount)).thenReturn(mockAccount);
		Account serviceAccount = accountService.createAccount(mockCustomer.getUserId(), mockAccount);
		assertNotNull(serviceAccount);
		assertEquals(mockCustomer, mockAccount.getCustomer());
		assertEquals(mockAccount, serviceAccount);
		verify(customerService).findById(mockCustomer.getUserId());
		verify(repo).save(mockAccount);
	}

	@Test
	void testCheckBalance_Success() {
		when(repo.findBalanceByUserId("Shri@2000")).thenReturn(7000.0);
		Double balance = accountService.checkBalance("Shri@2000");
		assertEquals(7000.0, balance);
		verify(repo).findBalanceByUserId("Shri@2000");
	}

	@Test
	void testCheckBalance_Failure() {
		when(repo.findBalanceByUserId("Shri@2000")).thenReturn(null);

		NoAccountError thrown = assertThrows(NoAccountError.class, () -> {
			accountService.checkBalance("Shri@2000");
		});
		ResponseEntity<Object> response = new WalletExceptions().NoAccountError(thrown);
		assertEquals("User does not have an account.", String.valueOf(response.getBody()));
		verify(repo).findBalanceByUserId("Shri@2000");
	}

}
