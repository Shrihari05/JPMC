package com.tcs.shrihari.parallel_project.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;

import com.tcs.shrihari.parallel_project.bean.Account;
import com.tcs.shrihari.parallel_project.bean.Customer;
import com.tcs.shrihari.parallel_project.bean.DBConnection;
import com.tcs.shrihari.parallel_project.bean.Transaction;
import com.tcs.shrihari.parallel_project.exceptions.NoTransactionException;
import com.tcs.shrihari.parallel_project.exceptions.ReceipientNotPresentError;
import com.tcs.shrihari.parallel_project.exceptions.WithDrawError;
import com.tcs.shrihari.parallel_project.service.ServiceClass;

public class DaoClass implements DaoInterface {

	public final static Connection connection = DBConnection.connectToDb();

	
	@Override
	public Customer login(Customer c1) throws SQLException {

		String username = "";
		String password = "";
		long accountNumber = 0l;
		String userName = "";
		String name = "";
		Date dob = null;
		long phone = 0l;
		String Address = "";
		String accountType = "";
		double balance = 0l;
		int acc = 0;
		
			PreparedStatement ps1 = connection
					.prepareStatement("select * from Customer where username=? and password=?");
			ps1.setString(1, c1.getUsername());
			ps1.setString(2, c1.getPassword());
			ResultSet result = ps1.executeQuery();
			while (result.next()) {
				username = result.getString(1);
				password = result.getString(2);

			}
			ps1.close();
			PreparedStatement ps2 = connection.prepareStatement("select * from Account where username=?");
		
			ps2.setString(1, c1.getUsername());
			ResultSet rs = ps2.executeQuery();
			while (rs.next()) {
				accountNumber = rs.getLong(1);
				userName = rs.getString(2);
				name = rs.getString(3);
				dob = rs.getDate(4);
				phone = rs.getLong(5);
				Address = rs.getString(6);
				accountType = rs.getString(7);
				balance = rs.getDouble(8);
				acc++;
			}

			
			ps2.close();

		
		if (acc != 0) {
			

			return new Customer(username, password,
					new Account(accountNumber, userName, name, dob, phone, Address, accountType, balance));
		} else
			return new Customer(username, password, null);
	}

	@Override
	public int signUp(Customer c1) throws SQLException {
		int result = 0;
		
			PreparedStatement ps = connection.prepareStatement("insert into Customer values(?,?)");
			ps.setString(1, c1.getUsername());
			ps.setString(2, c1.getPassword());
			result = ps.executeUpdate();
			ps.close();

		
		return result;
	}

	@Override
	public int createAccount(Account a) throws SQLException {
		// TODO Auto-generated method stub
		int result = 0;
		
			PreparedStatement ps = connection.prepareStatement("insert into Account values(?,?,?,?,?,?,?,?)");
			ps.setLong(1, a.getAccountNumber());
			ps.setString(2, a.getUserName());
			ps.setString(3, a.getName());
			ps.setDate(4, a.getDob());
			ps.setLong(5, a.getPhone());
			ps.setString(6, a.getAddress());
			ps.setString(7, a.getAccountType());
			ps.setDouble(8, a.getBalance());

			result = ps.executeUpdate();
			ps.close();

		
		return result;
	}

	@Override
	public boolean deposit(double amount, Account a,String operation) {
		int result = 0;
		double balance = 0.0;
		try {
			PreparedStatement ps = connection.prepareStatement("select balance from Account where accountNumber=?");
			ps.setLong(1, a.getAccountNumber());

			ResultSet res = ps.executeQuery();
			while (res.next()) {
				balance = res.getDouble(1);
			}
			ps.close();
			a.setBalance(balance + amount);
			PreparedStatement ps1 = connection.prepareStatement("update Account set balance=? where accountNumber=?");
			ps1.setDouble(1, balance + amount);
			ps1.setLong(2, a.getAccountNumber());
			result = ps1.executeUpdate();
			ps1.close();
			if (result!=0&&operation.equalsIgnoreCase("Deposit")) {
				PreparedStatement p = connection.prepareStatement("insert into Transaction values(?,?,?,?,?,?,?,?)");
				p.setLong(1, new ServiceClass().generateTransactionNumber());
				p.setTimestamp(2, new java.sql.Timestamp(System.currentTimeMillis()));
				p.setLong(3, a.getAccountNumber());
				p.setString(4, a.getUserName());
				p.setLong(5, 0);
				p.setString(6, "-");
				
				p.setDouble(7, amount);
				p.setString(8, "Deposit");
				if (p.executeUpdate() == 1) {
					result = 1;
				} else {
					result = 0;
				}
				p.close();
			}
		} catch (SQLException e) {
			
			System.out.println("Deposit error");
		}
		if (result == 0)
			return false;
		else
			return true;
	}
	

	@Override
	public boolean withdraw(double amount, Account a,String operation) throws WithDrawError {
		int result = 0; 
		double balance = 0.0;
		try {
			PreparedStatement ps = connection.prepareStatement("select balance from Account where accountNumber=?");
			ps.setLong(1, a.getAccountNumber());

			ResultSet res = ps.executeQuery();
			while (res.next()) {
				balance = res.getDouble(1);

			}
			if (balance >= amount) {
				a.setBalance(balance - amount);
				PreparedStatement ps1 = connection
						.prepareStatement("update Account set balance=? where accountNumber=?");
				ps1.setDouble(1, balance - amount);
				ps1.setLong(2, a.getAccountNumber());
				result = ps1.executeUpdate();
				
				ps1.close();
			} else {
				throw new WithDrawError("Balance insufficient");
			}
			if (result!=0&&operation.equals("Withdraw")) {
				PreparedStatement p = connection.prepareStatement("insert into Transaction values(?,?,?,?,?,?,?,?)");
				p.setLong(1, new ServiceClass().generateTransactionNumber());
				p.setTimestamp(2, new java.sql.Timestamp(System.currentTimeMillis()));
				p.setLong(3, a.getAccountNumber());
				p.setString(4, a.getUserName());
				p.setLong(5, 0);
				p.setString(6, "-");
				p.setDouble(7, amount);
				p.setString(8, "Withdraw");
				if (p.executeUpdate() == 1) {
					result = 1;
				} else {
					result = 0;
				}
				p.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Withdraw error");
		}
		
		if (result == 0)
			return false;
		else
			return true;

	}

	@Override
	public boolean fundTransfer(String username, double amount, Customer c, Account a)
			throws ReceipientNotPresentError, WithDrawError {
		String rname = "";
		double raccNo = 0.0;
		boolean result = false;
		try {
			PreparedStatement ps = connection.prepareStatement("select name from Account where username=?");
			ps.setString(1, username);
			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				rname = rs.getString(1);
			} else {
				throw new ReceipientNotPresentError("User does not have an account in the wallet");
			}
			PreparedStatement ps2 = connection.prepareStatement("select * from Account where username=?");
			ps2.setString(1, username);
			ResultSet rs1 = ps2.executeQuery();
			long accountNumber = 0l;
			String userName = "";
			String name = "";
			Date dob = null;
			long phone = 0l;
			String Address = "";
			String accountType = "";
			double balance = 0.0;
			while (rs1.next()) {
				accountNumber = rs1.getLong(1);
				userName = rs1.getString(2);
				name = rs1.getString(3);
				dob = rs1.getDate(4);
				phone = rs1.getLong(5);
				Address = rs1.getString(6);
				accountType = rs1.getString(7);
				balance = rs1.getDouble(8);

			}
			rs.close();

			ps2.close();

			result = withdraw(amount, a,"Fund Transfer") && deposit(amount,
					new Account(accountNumber, userName, name, dob, phone, Address, accountType, balance),"Fund Transfer");
			if (result) {
				PreparedStatement p = connection.prepareStatement("insert into Transaction values(?,?,?,?,?,?,?,?)");
				p.setLong(1, new ServiceClass().generateTransactionNumber());
				p.setTimestamp(2, new java.sql.Timestamp(System.currentTimeMillis()));
				p.setLong(3, a.getAccountNumber());
				p.setString(4, a.getUserName());
				p.setLong(5, accountNumber);
				p.setString(6, userName);
				p.setDouble(7, amount);
				p.setString(8, "Fund Transfer");
				if (p.executeUpdate() == 1) {
					result = true;
				} else {
					result = false;
				}
				p.close();
			}

		} catch (SQLException e) {
			System.out.println(e);
		}
		return result;
	}

	@Override
	public ArrayList<Transaction> printTransactions(String username) throws NoTransactionException {
		ArrayList<Transaction> l = new ArrayList<>();
		try {
			PreparedStatement p = connection.prepareStatement("select * from Transaction where senderName=? or receiverName=? order by transactiontime");
			p.setString(1, username);
			p.setString(2, username);
			ResultSet rs = p.executeQuery();
			while (rs.next()) {
				l.add(new Transaction(rs.getLong(1), rs.getTimestamp(2), rs.getLong(3), rs.getString(4), rs.getLong(5),
						rs.getString(6), rs.getDouble(7),rs.getString(8)));
			}
		} catch (SQLException e) {

			throw new NoTransactionException("No transactions has been made.");
		}
		Collections.reverse(l);
		return l;

	}
	@Override
	public double checkBalance(Account account) {
		PreparedStatement p;
		double balance = 0.0;
		try {
			p = connection.prepareStatement("select balance from Account where accountNumber=?");
			p.setLong(1, account.getAccountNumber());
			ResultSet rs = p.executeQuery();
			if (rs.next()) {
				balance = rs.getDouble(1);
			} else {
				throw new SQLException();
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}

		return balance;
	}
	
	public void closeConnection() {
		new DBConnection().closeConnection(connection);
	}

}