package com.bank.wallet.repositories;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.bank.wallet.beans.Account;
import com.bank.wallet.beans.Customer;

public interface CustomerRepository extends CrudRepository<Customer, String>{

	Optional<Customer> findByUserIdAndPassword(String userId,String password);

}
