package com.bank.wallet.controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bank.wallet.beans.Account;
import com.bank.wallet.beans.Customer;
import com.bank.wallet.beans.Transactions;

import com.bank.wallet.services.AccountService;
import com.bank.wallet.services.CustomerService;
import com.bank.wallet.services.TransactionService;

@RestController
@RequestMapping("/wallets")
public class WalletController {

	@Autowired
	AccountService accountService;
	@Autowired
	CustomerService customerService;
	@Autowired
	TransactionService transactionService;

	// SignUp
	@PostMapping("/signup")
	public String signUp(@RequestBody Customer customer) {
		customerService.signUp(customer);
		return "Successfully registered";

	}

	// Login
	@GetMapping("/login")
	public String login(@RequestBody Customer customer)  {

		return customerService.login(customer)?"Login successful":"Login failed!Please enter valid credentials!";
		

	}

	// Create Account
	@PostMapping("/{userId}/create-account")
	public String createAccount(@PathVariable String userId, @RequestBody Account account)  {

		accountService.createAccount(userId,account);
		return "Account created successfully";
		
	}

	// Check Balance
	@GetMapping("/{userid}/balance")
	public String checkBalance(@PathVariable String userid) {

		Double balance = accountService.checkBalance(userid);
		return String.valueOf("Balance = " + balance);

	}

	// deposit
	@PostMapping("/{userid}/{amount}")
	public String deposit(@PathVariable String userid, @PathVariable double amount) {
		transactionService.deposit(userid, amount);
		return "Amount deposited successfully";

	}

	// withdraw
	@GetMapping("/{userid}/{amount}")
	public String withdraw(@PathVariable String userid, @PathVariable double amount) {
		transactionService.withdraw(userid, amount);
		return "Amount withdrawn successfully";

	}

//	//fund transfer
	@PostMapping("/{senderid}/{receiverid}/{amount}")
	public String fundTransfer(@PathVariable String senderid, @PathVariable String receiverid,
			@PathVariable double amount) {
		transactionService.fundTransfer(senderid, receiverid, amount);
		return "Fund transfer is successful";

	}

//	//Print transaction
	@GetMapping("/{userid}/transactions")
	public Iterable<Transactions> printTransaction(@PathVariable String userid) {
		ArrayList<Transactions> result=new ArrayList<>();
		Iterable<Transactions> transactions = transactionService.printTransactions(userid);
		transactions.forEach(result::add);
		Collections.reverse(result);
		return result;

	}

}
