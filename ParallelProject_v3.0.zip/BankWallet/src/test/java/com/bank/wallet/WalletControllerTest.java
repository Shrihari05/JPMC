package com.bank.wallet;

import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.test.web.servlet.MockMvc;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.eq;
import com.bank.wallet.beans.Account;
import com.bank.wallet.beans.Customer;
import com.bank.wallet.beans.Transactions;
import com.bank.wallet.controller.WalletController;
import com.bank.wallet.exceptions.AccountCreationError;
import com.bank.wallet.exceptions.LoginError;
import com.bank.wallet.exceptions.NoAccountError;
import com.bank.wallet.exceptions.NoUserError;
import com.bank.wallet.exceptions.SignUpError;
import com.bank.wallet.services.AccountService;
import com.bank.wallet.services.CustomerService;
import com.bank.wallet.services.TransactionService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import static org.mockito.Mockito.when;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.any;
import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

@WebMvcTest(WalletController.class)

public class WalletControllerTest {
	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private AccountService accountService;
	@MockBean
	private CustomerService customerService;
	@MockBean
	private TransactionService transactionService;
	@Autowired
	private ObjectMapper objectMapper;
	Customer mockCustomer, mockReceiver;
	Account mockAccount, mockReceiverAccount;
	Transactions mockTransaction;

	@BeforeEach
	void setUp() throws ParseException {
		SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
		mockCustomer = new Customer("Shri@2000", "Paltan@2025");
		mockAccount = new Account(27890190, mockCustomer, "Shrihari",
				new java.sql.Date(df.parse("2000-09-09").getTime()), 9090989890l, "Whitefield,Bangalore", "Savings",
				5000.0);
		mockReceiver = new Customer("Hari@2000", "Mumbai@2025");
		mockReceiverAccount = new Account(27890189, mockReceiver, "Hari S",
				new java.sql.Date(df.parse("2000-09-09").getTime()), 9090989890l, "Whitefield,Bangalore", "Savings",
				5000.0);
		mockTransaction = new Transactions(49002904903l, new java.sql.Timestamp(System.currentTimeMillis()),
				mockAccount.getAccountNumber(), mockAccount.getCustomer(), 0l, null, 0, "");

	}

	@Test
	void testLogin_Valid() throws Exception {
		// Given
		Customer mockCustomer = new Customer("Shri@2000", "Paltan@2025");

		when(customerService.login(any(Customer.class))).thenReturn(true);
		mockMvc.perform(get("/wallets/login").contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(mockCustomer))).andExpect(status().isOk())
				.andExpect(content().string("Login successful"));
		verify(customerService).login(any(Customer.class));

	}

	@Test
	void testLogin_Invalid() throws Exception {

		when(customerService.login(any(Customer.class))).thenReturn(false);
		mockMvc.perform(get("/wallets/login").contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(mockCustomer))).andExpect(status().isOk())
				.andExpect(content().string("Login failed!Please enter valid credentials!"));

		verify(customerService).login(any(Customer.class));
	}

	@Test
	void testLogin_Error() throws Exception {

		when(customerService.login(any(Customer.class))).thenThrow(new LoginError());
		mockMvc.perform(get("/wallets/login").contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(mockCustomer))).andExpect(status().isNotFound())
				.andExpect(content().string("Login failed! Please try again!"));

		verify(customerService).login(any(Customer.class));
	}

	@Test
	void testSignUp() throws JsonProcessingException, Exception {
		Customer mockCustomer = new Customer("Shri@2000", "Paltan@2025");

		when(customerService.signUp(any(Customer.class))).thenReturn(mockCustomer);
		mockMvc.perform(post("/wallets/signup").contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(mockCustomer))).andExpect(status().isOk())
				.andExpect(content().string("Successfully registered"));
		verify(customerService).signUp(any(Customer.class));
	}

	@Test
	void testSignUp_Error() throws JsonProcessingException, Exception {
		Customer mockCustomer = new Customer("Shri@2000", "Paltan@2025");

		when(customerService.signUp(any(Customer.class))).thenThrow(new SignUpError());
		mockMvc.perform(post("/wallets/signup").contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(mockCustomer))).andExpect(status().isNotFound())
				.andExpect(content().string("Signup failed! Please try again!"));
		verify(customerService).signUp(any(Customer.class));
	}

	@Test
	void testCreateAccount_Success() throws JsonProcessingException, Exception {
		Customer mockCustomer = new Customer("Shri@2000", "Paltan@2025");
		when(customerService.findById(eq(mockCustomer.getUserId()))).thenReturn(Optional.of(mockCustomer));

		when(accountService.createAccount(eq(mockCustomer.getUserId()), any(Account.class))).thenReturn(mockAccount);
		mockMvc.perform(post("/wallets/Shri@2000/create-account").contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(mockAccount))).andExpect(status().isOk())
				.andExpect(content().string("Account created successfully"));
		verify(accountService).createAccount(eq(mockCustomer.getUserId()), any(Account.class));
	}

	@Test
	void testCreateAccount_Failure() throws JsonProcessingException, Exception {

		when(customerService.findById(eq("errorUser"))).thenReturn(null);

		when(accountService.createAccount(eq("errorUser"), any(Account.class))).thenThrow(new NoUserError());
		mockMvc.perform(post("/wallets/errorUser/create-account").contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(mockAccount))).andExpect(status().isNotFound())
				.andExpect(content().string("User doesn't exists."));
		verify(accountService).createAccount(eq("errorUser"), any(Account.class));
	}

	@Test
	void testCreateAccount_Error() throws JsonProcessingException, Exception {

		when(customerService.findById(mockCustomer.getUserId())).thenReturn(Optional.of(mockCustomer));

		when(accountService.createAccount(eq(mockCustomer.getUserId()), any(Account.class)))
				.thenThrow(new AccountCreationError());
		mockMvc.perform(post("/wallets/Shri@2000/create-account").contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(mockAccount))).andExpect(status().isNotFound())
				.andExpect(content().string("Account creation failed! Please Try again!"));
		verify(accountService).createAccount(eq(mockCustomer.getUserId()), any(Account.class));
	}

	@Test
	void testCheckBalance() throws Exception {
		when(accountService.checkBalance(mockCustomer.getUserId())).thenReturn(5000.0);

		mockMvc.perform(get("/wallets/{userid}/balance", "Shri@2000").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andExpect(content().string("Balance = " + 5000.0));
		verify(accountService).checkBalance(mockCustomer.getUserId());
	}

	@Test
	void testCheckBalance_InValid() throws Exception {
		String userId = "errorUser";

		when(accountService.checkBalance(userId)).thenThrow(new NoAccountError());

		mockMvc.perform(get("/wallets/{userid}/balance", userId).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isNotFound()).andExpect(content().string("User does not have an account."));
		verify(accountService).checkBalance(userId);
	}

	@Test
	void testDeposit() throws Exception {
		double amount = 5000.0;
		mockTransaction.setAmount(1000.0);
		mockTransaction.setType("Credit");
		when(transactionService.deposit("Shri@2000", amount)).thenReturn(mockTransaction);
		mockMvc.perform(post("/wallets/{userid}/{amount}", "Shri@2000", amount).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andExpect(content().string("Amount deposited successfully"));

		verify(transactionService).deposit("Shri@2000", amount);
	}

	@Test
	void testWithdraw() throws Exception {
		double amount = 1000.0;
		mockTransaction.setAmount(1000.0);
		mockTransaction.setType("Debit");
		when(transactionService.deposit("Shri@2000", amount)).thenReturn(mockTransaction);
		mockMvc.perform(get("/wallets/{userid}/{amount}", "Shri@2000", amount).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andExpect(content().string("Amount withdrawn successfully"));

		verify(transactionService).withdraw("Shri@2000", amount);
	}

	@Test
	void testFunTransfer() throws Exception {
		double amount = 1000.0;
		mockTransaction.setAmount(1000.0);
		mockTransaction.setType("Fund Transfer");
		when(transactionService.fundTransfer("Shri@2000", "Hari@2000", amount)).thenReturn(mockTransaction);
		mockMvc.perform(post("/wallets/{userid}/{receiverid}/{amount}", "Shri@2000", "Hari@2000", amount)
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
				.andExpect(content().string("Fund transfer is successful"));

		verify(transactionService).fundTransfer("Shri@2000", "Hari@2000", amount);
	}

	@Test
	void testPrintTransactions() throws Exception {
		List<Transactions> mockTransactions = new ArrayList<>();

		mockTransactions.add(mockTransaction);

		List<Transactions> newTransactions = new ArrayList<>(mockTransactions);
		Collections.reverse(newTransactions);

		when(transactionService.printTransactions(eq(mockCustomer.getUserId()))).thenReturn(mockTransactions);

		mockMvc.perform(
				get("/wallets/{userid}/transactions", mockCustomer.getUserId()).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andExpect(content().json(objectMapper.writeValueAsString(newTransactions)));

		verify(transactionService).printTransactions(eq(mockCustomer.getUserId()));

	}

}
