package com.bank.wallet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankWalletApplicationTests {

	@Test
	void contextLoads() {
	}

}
