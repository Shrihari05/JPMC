package com.bank.wallet.services;



import java.util.Optional;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bank.wallet.repositories.AccountRepository;
import com.bank.wallet.beans.Account;
import com.bank.wallet.beans.Customer;
import com.bank.wallet.exceptions.AccountCreationError;
import com.bank.wallet.exceptions.NoAccountError;
import com.bank.wallet.exceptions.NoUserError;

@Service
public class AccountService  {
	
	@Autowired
	CustomerService customerService;
	@Autowired
	AccountRepository accountRepository;
	public AccountService(AccountRepository accountRepository) {
		this.accountRepository=accountRepository;
	}
	
	public Long generateAccountNumber() {
		long accNo = new Random(System.currentTimeMillis()).nextLong((long) Math.pow(10, 8));
		return accNo;
	}

	//For Transaction Class
	public Optional<Account> getAccountByUserId(String userId) {
		return accountRepository.findByCustomerUserId(userId);
		
	}
	//createAccount
	public Account createAccount(String userId,Account account) {
		
		Customer customer=customerService.findById(userId).stream().findFirst().orElse(null);
		if(customer==null) {
			throw new NoUserError();
		}
		account.setAccountNumber(generateAccountNumber());
		account.setCustomer(customer);
		Account result_account;
		try {
		result_account=accountRepository.save(account);
		}catch(Exception e) {
			throw new AccountCreationError();
		}
	
		return result_account;
	}
	
	//updateAccount
	public Account updateAccount(Account account) {
		return accountRepository.save(account);
	}
	
//	//checkBalance
	public Double checkBalance(String userId) throws NoAccountError {
		Double balance=accountRepository.findBalanceByUserId(userId);
		if(balance==null) {
			throw new NoAccountError();
		}
		return balance;
	}
	


}
