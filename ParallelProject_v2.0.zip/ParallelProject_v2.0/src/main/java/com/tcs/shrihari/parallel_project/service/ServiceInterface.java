package com.tcs.shrihari.parallel_project.service;

import java.sql.SQLException;
import java.util.ArrayList;

import com.tcs.shrihari.parallel_project.bean.Account;
import com.tcs.shrihari.parallel_project.bean.Customer;
import com.tcs.shrihari.parallel_project.bean.Transaction;
import com.tcs.shrihari.parallel_project.exceptions.NoTransactionException;
import com.tcs.shrihari.parallel_project.exceptions.ReceipientNotPresentError;
import com.tcs.shrihari.parallel_project.exceptions.WithDrawError;

public interface ServiceInterface {
	Customer login(Customer c1) throws SQLException;
	boolean signUp(Customer c1) throws SQLException;
	boolean createAccount(Account a) throws SQLException;
	boolean deposit(double amount,Account a,String operation);
	boolean withdraw(double amount,Account a,String operation) throws WithDrawError;
	boolean fundTransfer(String userid,double amount,Customer c,Account a) throws ReceipientNotPresentError, WithDrawError;
	ArrayList<Transaction> printTransactions(String username) throws NoTransactionException;
	double checkBalance(Account account);
	//void closeConnection();
}
