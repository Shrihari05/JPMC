package com.bank.wallet.beans;

import java.sql.Timestamp;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne; 
import jakarta.persistence.JoinColumn; 

@Entity
public class Transactions { 
    @Id    
    private long refNumber;

    private Timestamp dateTime;
    private long senderAccNumber;

    @ManyToOne
    @JoinColumn(name = "sender_user_id", referencedColumnName = "userId") // Foreign key
    private Customer sender;

    private long receiverAccNumber;

    @ManyToOne
    @JoinColumn(name = "receiver_user_id", referencedColumnName = "userId") // Foreign key
    private Customer receiver;

    private double amount;
    private String type;

    public Transactions() {}

    
    public Transactions(long refNumber, Timestamp dateTime, long senderAccNumber, Customer sender,
                        long receiverAccNumber, Customer receiver, double amount, String type) {
        this.refNumber = refNumber;
        this.dateTime = dateTime;
        this.senderAccNumber = senderAccNumber;
        this.sender = sender;
        this.receiverAccNumber = receiverAccNumber;
        this.receiver = receiver;
        this.amount = amount;
        this.type = type;
    }

//      public Transactions(long refNumber, Timestamp dateTime, long senderAccNumber, String senderId,
//                        long receiverAccNumber, String receiverId, double amount, String type) {
//        this.refNumber = refNumber;
//        this.dateTime = dateTime;
//        this.senderAccNumber = senderAccNumber;
//        this.sender = new Customer(senderId, ""); 
//        this.receiverAccNumber = receiverAccNumber;
//        this.receiver = new Customer(receiverId, ""); 
//        this.amount = amount;
//        this.type = type;
//    }


    public long getRefNumber() {
        return refNumber;
    }

    public void setRefNumber(long refNumber) {
        this.refNumber = refNumber;
    }

    public Timestamp getDateTime() {
        return dateTime;
    }

    public void setDateTime(Timestamp dateTime) {
        this.dateTime = dateTime;
    }

    public long getSenderAccNumber() {
        return senderAccNumber;
    }

    public void setSenderAccNumber(long senderAccNumber) {
        this.senderAccNumber = senderAccNumber;
    }

    public Customer getSender() {
        return sender;
    }

    public void setSender(Customer sender) {
        this.sender = sender;
    }

    public long getReceiverAccNumber() {
        return receiverAccNumber;
    }

    public void setReceiverAccNumber(long receiverAccNumber) {
        this.receiverAccNumber = receiverAccNumber;
    }

    public Customer getReceiver() {
        return receiver;
    }

    public void setReceiver(Customer receiver) {
        this.receiver = receiver;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}