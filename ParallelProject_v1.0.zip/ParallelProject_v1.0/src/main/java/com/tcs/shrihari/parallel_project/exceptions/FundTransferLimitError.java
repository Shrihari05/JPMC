package com.tcs.shrihari.parallel_project.exceptions;

public class FundTransferLimitError extends Exception {
public FundTransferLimitError(String message) {
	super(message);
}
}
