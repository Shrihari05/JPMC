package com.tcs.shrihari.parallel_project.exceptions;

public class MobileNumberError extends Exception {
public MobileNumberError(String message) {
	super(message);
}
}
