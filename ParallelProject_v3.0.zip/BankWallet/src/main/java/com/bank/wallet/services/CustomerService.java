package com.bank.wallet.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bank.wallet.beans.Customer;
import com.bank.wallet.exceptions.LoginError;
import com.bank.wallet.exceptions.SignUpError;
import com.bank.wallet.repositories.CustomerRepository;

@Service
public class CustomerService {
	@Autowired
CustomerRepository customerRepository;
	public Customer signUp(Customer customer) {
		Customer result_customer;
		try {
		result_customer=customerRepository.save(customer);
		}catch(Exception e){
			throw new SignUpError();
		}
		return result_customer;
	}
	
	public boolean login(Customer customer) {
		Optional<Customer> result_customer;
		try {
		result_customer=customerRepository.findByUserIdAndPassword(customer.getUserId(),customer.getPassword());
		if(result_customer.isEmpty()) {
			return false;
		}
		}catch(Exception e){
			throw new LoginError();
		}
		return true;
	}
	
	//Account and Transaction
	public Optional<Customer> findById(String userId) {
		return customerRepository.findById(userId);
	}
}



