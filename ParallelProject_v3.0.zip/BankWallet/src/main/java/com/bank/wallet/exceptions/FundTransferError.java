package com.bank.wallet.exceptions;

public class FundTransferError extends RuntimeException {
	
}
