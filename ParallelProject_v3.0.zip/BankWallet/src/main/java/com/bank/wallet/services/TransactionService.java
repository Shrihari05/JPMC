package com.bank.wallet.services;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.stereotype.Service;

import com.bank.wallet.beans.Account;
import com.bank.wallet.beans.Customer;
import com.bank.wallet.beans.Transactions;
import com.bank.wallet.exceptions.NoTransactionException;
import com.bank.wallet.exceptions.NoUserError;
import com.bank.wallet.exceptions.WithdrawError;
import com.bank.wallet.exceptions.WithdrawLimitError;
import com.bank.wallet.exceptions.DepositError;
import com.bank.wallet.exceptions.FundTransferError;
import com.bank.wallet.exceptions.FundTransferLimitError;
import com.bank.wallet.exceptions.NoAccountError;
import com.bank.wallet.repositories.AccountRepository;
import com.bank.wallet.repositories.TransactionRepository;

@Service
public class TransactionService {

	TransactionRepository transactionRepository;
	@Autowired
	AccountRepository accountRepository;
	@Autowired
	AccountService accountService;
	@Autowired
	CustomerService customerService;

	public TransactionService(TransactionRepository transactionRepository) {
		this.transactionRepository = transactionRepository;

	}

	// generating random number
	public Long generateTransactionNumber() {
		long tno = new Random(System.currentTimeMillis()).nextLong((long) Math.pow(10, 10));
		return tno;
	}

	// printing all transactions
	public Iterable<Transactions> printTransactions(String userId) {
		Iterable<Transactions> transactions=transactionRepository.findBySenderUserId(userId);
		if(transactions==null) {
			throw new NoTransactionException();
		}
		return transactions;
	}

	public Account creditAmount(String userId, double amount) {
		Account account = accountService.getAccountByUserId(userId).stream().findFirst().orElse(null);
		if(account==null) {
			throw new NoAccountError();
		}
		account.setBalance(account.getBalance() + amount);
		return accountService.updateAccount(account);
	}

	public Account debitAmount(String userId, double amount) {
		Account account = accountService.getAccountByUserId(userId).stream().findFirst().orElse(null);
		if(account==null) {
			throw new NoAccountError();
		}
		if(account.getBalance()<amount||(amount>5000||amount<100)) {
			throw new WithdrawLimitError();
		}
		account.setBalance(account.getBalance() - amount);
		return accountService.updateAccount(account);
	}

	//deposit
	public Transactions deposit(String userId, double amount) {
		Account account = creditAmount(userId, amount);
		Transactions depositTransaction;
		if (account == null)
			throw new DepositError();
		try {
		depositTransaction=transactionRepository
				.save(new Transactions(generateTransactionNumber(), new java.sql.Timestamp(System.currentTimeMillis()),
						account.getAccountNumber(), account.getCustomer(), 0, null, amount, "Credit"));
		}catch(Exception e) {
			account.setBalance(account.getBalance() - amount);
			accountService.updateAccount(account);
			System.out.println(e);
			throw new DepositError();
			
		}
	
		return depositTransaction;
	}

	//withdraw
	public Transactions withdraw(String userId, double amount) {
		Account account = debitAmount(userId, amount);
		Transactions withdrawTransaction;
		if (account == null)
			throw new WithdrawError();
		
		try{
			withdrawTransaction=transactionRepository
				.save(new Transactions(generateTransactionNumber(), new java.sql.Timestamp(System.currentTimeMillis()),
						account.getAccountNumber(), account.getCustomer(), 0, null, amount, "Debit"));
		}catch(Exception e) {
			account.setBalance(account.getBalance()+amount);
			accountService.updateAccount(account);
			throw new WithdrawError();
		}
		
		return withdrawTransaction; 	
	}

	// fundtransfer
	public Transactions fundTransfer(String senderId, String receiverId, double amount) {
		Transactions fundTransaction;
		Customer customer=customerService.findById(receiverId).stream().findFirst().orElse(null);
		if(customer==null) {
			throw new NoUserError();
		}
		if(amount<100||amount>5000) {
			throw new FundTransferLimitError();
		}
		Account senderAccount = debitAmount(senderId, amount);
		Account receiverAccount = creditAmount(receiverId, amount);
		if ((senderAccount != null) && (receiverAccount != null)) {
			try {
				fundTransaction=transactionRepository.save(new Transactions(generateTransactionNumber(),
					new java.sql.Timestamp(System.currentTimeMillis()), senderAccount.getAccountNumber(),
					senderAccount.getCustomer(), receiverAccount.getAccountNumber(), receiverAccount.getCustomer(),
					amount, "Fund Transfer"));
			}catch(Exception e) {
				senderAccount.setBalance(senderAccount.getBalance()+amount);
				accountService.updateAccount(senderAccount);
				receiverAccount.setBalance(receiverAccount.getBalance()-amount);
				accountService.updateAccount(receiverAccount);
				throw new FundTransferError();
			}
			
				return fundTransaction;
			

		} else {
			senderAccount.setBalance(senderAccount.getBalance()+amount);
			accountService.updateAccount(senderAccount);
			receiverAccount.setBalance(receiverAccount.getBalance()-amount);
			accountService.updateAccount(receiverAccount);
			throw new FundTransferError();
		}

	}

}
