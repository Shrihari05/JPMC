package com.tcs.shrihari.parallel_project.bean;

import java.sql.Date;

public class Account{
	private long accountNumber;
	private String userName;
	private String name;
	private Date dob;
	private long phone;
	private String Address;
	private String accountType;
	private double balance;
	
	public Account(long accountNumber, String userName, String name, Date dob, long phone, String address,
			String accountType, double balance) {
		super();
		this.accountNumber = accountNumber;
		this.userName = userName;
		this.name = name;
		this.dob = dob;
		this.phone = phone;
		Address = address;
		this.accountType = accountType;
		this.balance = balance;
	}
	public long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public long getPhone() {
		return phone;
	}
	public void setPhone(long phone) {
		this.phone = phone;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
		
}
