package com.bank.wallet.exceptions;

public class AccountCreationError extends RuntimeException {
	
}
