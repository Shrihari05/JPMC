package com.tcs.shrihari.parallel_project.bean;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	private static Connection connection;
	public static final String DRIVER_NAME = "com.mysql.cj.jdbc.Driver";
	public static final String URL_TO_CONNECT = "jdbc:mysql://localhost:3306/tcs";
	public static final String DB_USERNAME = "root";
	public static final String DB_PASSWORD = "Root123$";

	public static Connection connectToDb() {
		try {
			Class.forName(DRIVER_NAME);
			connection = DriverManager.getConnection(URL_TO_CONNECT, DB_USERNAME, DB_PASSWORD);

		} catch (ClassNotFoundException | SQLException e) {
			
			System.out.println("Database Connection Error");
		}
		return connection;
	}

	public void closeConnection(Connection c) {
		try {
			c.close();
		} catch (SQLException e) {
			System.out.println("Error in closing Connection");
		}
	}
}
