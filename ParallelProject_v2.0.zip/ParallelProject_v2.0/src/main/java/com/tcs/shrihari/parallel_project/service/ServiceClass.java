package com.tcs.shrihari.parallel_project.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;

import com.tcs.shrihari.parallel_project.bean.Account;
import com.tcs.shrihari.parallel_project.bean.Customer;
import com.tcs.shrihari.parallel_project.bean.Transaction;
import com.tcs.shrihari.parallel_project.dao.DaoClass;
import com.tcs.shrihari.parallel_project.exceptions.NoTransactionException;
import com.tcs.shrihari.parallel_project.exceptions.ReceipientNotPresentError;
import com.tcs.shrihari.parallel_project.exceptions.WithDrawError;
@Service
public class ServiceClass implements ServiceInterface {
	
	@Autowired
	DaoClass dao;

	public Long generateAccountNumber() {
		long accNo = new Random(System.currentTimeMillis()).nextLong((long) Math.pow(10, 8));
		return accNo;
	}

	public Long generateTransactionNumber() {
		long tno = new Random(System.currentTimeMillis()).nextLong((long) Math.pow(10, 10));
		return tno;
	}

	@Override
	public boolean deposit(double amount, Account a,String operation) {
		return dao.deposit(amount, a,operation);
	}

	@Override
	public boolean withdraw(double amount, Account a,String operation) throws WithDrawError {

		return dao.withdraw(amount, a,operation);

	}

	@Override
	public ArrayList<Transaction> printTransactions(String username) throws NoTransactionException {
		return dao.printTransactions(username);

	}

	@Override
	public Customer login(Customer c1) throws SQLException {
		
		
		Customer c2 = dao.login(c1);
		if(c2==null) {
			return c2;
		}
		
		
		return c2;

	}

	@Override
	public boolean signUp(Customer c1) throws SQLException {
		boolean res = false;
		if (dao.signUp(c1) == 1) {
			res = true;
		}
		return res;

	}

	@Override
	public boolean createAccount(Account a) throws SQLException {
		boolean res = false;
		a.setAccountNumber(new ServiceClass().generateAccountNumber());
		if (dao.createAccount(a) == 1) {
			res = true;
		}
		return res;

	}

	@Override
	public boolean fundTransfer(String userid, double amount, Customer c, Account a)
			throws ReceipientNotPresentError, WithDrawError {
		boolean result = false;

		result = dao.fundTransfer(userid, amount, c, a);

		return result;

	}

	@Override
	public double checkBalance(Account account) {
		// TODO Auto-generated method stub
		return dao.checkBalance(account);
	}


}
