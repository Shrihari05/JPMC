package com.bank.wallet.exceptions;

public class NoAccountError extends RuntimeException {
	
}
