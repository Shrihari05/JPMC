package com.tcs.shrihari.parallel_project.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.tcs.shrihari.parallel_project.bean.Account;
import com.tcs.shrihari.parallel_project.bean.Customer;
import com.tcs.shrihari.parallel_project.bean.DBConnection;
import com.tcs.shrihari.parallel_project.bean.Transaction;
import com.tcs.shrihari.parallel_project.exceptions.NoTransactionException;
import com.tcs.shrihari.parallel_project.exceptions.ReceipientNotPresentError;
import com.tcs.shrihari.parallel_project.exceptions.WithDrawError;
import com.tcs.shrihari.parallel_project.service.ServiceClass;

@Repository
public class DaoClass implements DaoInterface {

	NamedParameterJdbcTemplate npJdbcTemplate;
	

	@Autowired
	public void setDataSource(DataSource dataSource) {

		this.npJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
	}

	public class AccountMapper implements RowMapper<Account> {
		@Override
		public Account mapRow(ResultSet rs, int rownum) throws SQLException {
			return new Account(rs.getLong(1), rs.getString(2), rs.getString(3), rs.getDate(4), rs.getLong(5),
					rs.getString(6), rs.getString(7), rs.getDouble(8));
		}
	}

	public class CustomerRowMapper implements RowMapper<Customer> {
		@Override
		public Customer mapRow(ResultSet rs, int rownum) throws SQLException {
			return new Customer(rs.getString(1), rs.getString(2));
		}
	}

	public class TransactionMapper implements RowMapper<Transaction> {
		@Override
		public Transaction mapRow(ResultSet rs, int rownum) throws SQLException {
			return new Transaction(rs.getLong(1), rs.getTimestamp(2), rs.getLong(3), rs.getString(4), rs.getLong(5),
					rs.getString(6), rs.getDouble(7), rs.getString(8));
		}
	}

	@Override
	public Customer login(Customer c1) {

		String username = "";
		String password = "";
		Customer c=null;
		try {
		c = npJdbcTemplate.queryForObject(
				"select username,password from Customer where username=:un and password=:p",
				new MapSqlParameterSource("un", c1.getUsername()).addValue("p", c1.getPassword()),
				new CustomerRowMapper());
		
		username = c.getUsername();
		password = c.getPassword();
		} catch (EmptyResultDataAccessException e) {
			c = null;
		}
		
		if(c==null) {
			return c;
		}
		Account a = null;
		try {
			a = npJdbcTemplate.queryForObject("select * from Account where username=:un",
					new MapSqlParameterSource("un", c1.getUsername()), new AccountMapper());

		} catch (EmptyResultDataAccessException e) {
			a = null;
		}

		if (a != null) {

			return new Customer(username, password, a);
		} else
			return new Customer(username, password, null);
	}

	@Override
	public int signUp(Customer c1) throws SQLException {
		int result = npJdbcTemplate.update("insert into Customer values(:un,:p)",
				new MapSqlParameterSource("un", c1.getUsername()).addValue("p", c1.getPassword()));

		return result;
	}

	@Override
	public int createAccount(Account a) throws SQLException {
		// TODO Auto-generated method stub
		int result = npJdbcTemplate.update("insert into Account values(:acc,:un,:n,:dob,:ph,:add,:at,:bal)",
				new MapSqlParameterSource("acc", a.getAccountNumber()).addValue("un", a.getUserName())
						.addValue("n", a.getName()).addValue("dob", a.getDob()).addValue("ph", a.getPhone())
						.addValue("at", a.getAccountType()).addValue("add", a.getAddress())
						.addValue("at", a.getAccountType()).addValue("bal", a.getBalance()));

		return result;
	}

	@Override
	public boolean deposit(double amount, Account a,String operation) {
		int result = 0;
		double balance = 0.0;
		try {
			balance = npJdbcTemplate.queryForObject("select balance from Account where accountNumber=:an",
					new MapSqlParameterSource("an", a.getAccountNumber()), Double.class);
			a.setBalance(balance + amount);
			result = npJdbcTemplate.update("update Account set balance=:bal where accountNumber=:acc",
					new MapSqlParameterSource("bal", balance + amount).addValue("acc", a.getAccountNumber()));

		} catch (EmptyResultDataAccessException e) {
			result = 0;
		}
		if(result!=0&&operation.equals("Deposit")) {
			result = npJdbcTemplate.update("insert into Transaction values(:tn,:t,:an,:un,:racc,:rn,:a,:s)",
					new MapSqlParameterSource("tn", new ServiceClass().generateTransactionNumber())
							.addValue("t", new java.sql.Timestamp(System.currentTimeMillis()))
							.addValue("an", a.getAccountNumber()).addValue("un", a.getUserName())
							.addValue("racc", 0).addValue("rn", "-")
							.addValue("a", amount).addValue("s", "Deposit"));
		}
		if (result == 0)
			return false;
		else
			return true;
	}
	
	
	@Override
	public boolean withdraw(double amount, Account a,String operation) throws WithDrawError {
		int result = 0;
		double balance = 0.0;

		try {
			balance = npJdbcTemplate.queryForObject("select balance from Account where accountNumber=:an",
					new MapSqlParameterSource("an", a.getAccountNumber()), Double.class);
			if (balance >= amount) {
				a.setBalance(balance - amount);
				result = npJdbcTemplate.update("update Account set balance=:bal where accountNumber=:acc",
						new MapSqlParameterSource("bal", balance - amount).addValue("acc", a.getAccountNumber()));
			} else {
				throw new WithDrawError("Balance insufficient");
			}

		} catch (EmptyResultDataAccessException e) {
			result = 0;
		}
		a.setBalance(balance - amount);
		if(result!=0&&operation.equals("Withdraw")) {
			result = npJdbcTemplate.update("insert into Transaction values(:tn,:t,:an,:un,:racc,:rn,:a,:s)",
					new MapSqlParameterSource("tn", new ServiceClass().generateTransactionNumber())
							.addValue("t", new java.sql.Timestamp(System.currentTimeMillis()))
							.addValue("an", a.getAccountNumber()).addValue("un", a.getUserName())
							.addValue("racc", 0).addValue("rn", "-")
							.addValue("a", amount).addValue("s", "Withdraw"));
		}
		if (result == 0)
			return false;
		else
			return true;

	}

	@Override
	public boolean fundTransfer(String username, double amount, Customer c, Account a)
			throws ReceipientNotPresentError, WithDrawError {
		String rname = "";
		double raccNo = 0.0;
		boolean result = false;
		Account rA = null;
		try {
			try {
				rname = npJdbcTemplate.queryForObject("select name from Account where username=:un",
						new MapSqlParameterSource("un", username), String.class);
			} catch (EmptyResultDataAccessException e) {
				throw new ReceipientNotPresentError("User does not have an account in the wallet");
			}
			rA = npJdbcTemplate.queryForObject("select * from Account where username=:un",
					new MapSqlParameterSource("un", username).addValue("n", a.getName()).addValue("dob", a.getDob())
							.addValue("ph", a.getPhone()).addValue("at", a.getAccountType())
							.addValue("add", a.getAddress()).addValue("at", a.getAccountType())
							.addValue("bal", a.getBalance()),
					new AccountMapper());
			
			result = withdraw(amount, a,"Fund Transfer") && deposit(amount, rA,"Fund Transfer");
			int r = 0;
			if (result) {
				r = npJdbcTemplate.update("insert into Transaction values(:tn,:t,:an,:un,:racc,:rn,:a,:s)",
						new MapSqlParameterSource("tn", new ServiceClass().generateTransactionNumber())
								.addValue("t", new java.sql.Timestamp(System.currentTimeMillis()))
								.addValue("an", a.getAccountNumber()).addValue("un", a.getUserName())
								.addValue("racc", rA.getAccountNumber()).addValue("rn", rA.getUserName())
								.addValue("a", amount).addValue("s", "Fund Transfer"));
			}
			if (r == 1) {
				result = true;
			} else {
				result = false;
			}

		} catch (EmptyResultDataAccessException e) {
			throw new ReceipientNotPresentError("User does not have an account in the wallet");
		}

		return result;
	}

	@Override
	public ArrayList<Transaction> printTransactions(String username) throws NoTransactionException {
		List<Transaction> l = new ArrayList<Transaction>();

		l = npJdbcTemplate.query("select * from Transaction where senderName=:sn or receiverName=:rn order by transactiontime",
				new MapSqlParameterSource("sn", username).addValue("rn", username), new TransactionMapper());
		if (l.isEmpty()) {
			throw new NoTransactionException("No Transactions has been done");
		}

		return (ArrayList<Transaction>) l;

	}

	@Override
	public double checkBalance(Account account) {

		double balance = 0.0;
		try {
			balance = npJdbcTemplate.queryForObject("select balance from Account where accountNumber=:an",
					new MapSqlParameterSource("an", account.getAccountNumber()), Double.class);
		} catch (EmptyResultDataAccessException e) {

		}

		return balance;
	}

}