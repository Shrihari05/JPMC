package com.tcs.shrihari.parallel_project;


import com.tcs.shrihari.parallel_project.ui.App;

public class Main {
	

	public static void main(String[] args) {

		System.out.println("Welcome to XYZ Bank");
		App app=new App();
		app.start();
	}

}
